USE WideWorldImportersDW;
SET NOCOUNT ON;
SET STATISTICS IO ON;
GO
/********************************************************************************************************************
 ************************Setup & Compression*************************************************************************
 ********************************************************************************************************************
 ********************************************************************************************************************
 ************************Create OLAP Table with a Clustered  Rowstore Index******************************************
 *******************************************************************************************************************/

CREATE TABLE dbo.fact_order_BIG (
	[Order Key] [bigint] NOT NULL CONSTRAINT PK_fact_order_BIG PRIMARY KEY CLUSTERED,
	[City Key] [int] NOT NULL,
	[Customer Key] [int] NOT NULL,
	[Stock Item Key] [int] NOT NULL,
	[Order Date Key] [date] NOT NULL,
	[Picked Date Key] [date] NULL,
	[Salesperson Key] [int] NOT NULL,
	[Picker Key] [int] NULL,
	[WWI Order ID] [int] NOT NULL,
	[WWI Backorder ID] [int] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Package] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Unit Price] [decimal](18, 2) NOT NULL,
	[Tax Rate] [decimal](18, 3) NOT NULL,
	[Total Excluding Tax] [decimal](18, 2) NOT NULL,
	[Tax Amount] [decimal](18, 2) NOT NULL,
	[Total Including Tax] [decimal](18, 2) NOT NULL,
	[Lineage Key] [int] NOT NULL);

--	Generate 231,412 * 100 rows of data in an OLTP table.  This takes a few minutes to execute, so we've already done it.
INSERT INTO dbo.fact_order_BIG
SELECT
	 [Order Key] + (250000 * ([Day Number] + ([Calendar Month Number] * 31))) AS [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM Fact.[Order]
CROSS JOIN
Dimension.Date
WHERE Date.Date <= '2013-04-10';

-- Add the typical NCI on the date column
CREATE NONCLUSTERED INDEX IX_fact_order_BIG ON dbo.fact_order_BIG ([order date key]);

-- How much data do we have?  23,141,200 Rows.  This took 49234 reads to execute and return data!
SELECT
	COUNT(*),
	MIN([order date key]),
	MAX([order date key])
FROM dbo.fact_order_BIG
WITH (INDEX(IX_fact_order_BIG));



CREATE TABLE dbo.fact_order_BIG_PAGE_COMPRESS (
	[Order Key] [bigint] NOT NULL CONSTRAINT PK_fact_order_BIG_PAGE_COMPRESS PRIMARY KEY CLUSTERED,
	[City Key] [int] NOT NULL,
	[Customer Key] [int] NOT NULL,
	[Stock Item Key] [int] NOT NULL,
	[Order Date Key] [date] NOT NULL,
	[Picked Date Key] [date] NULL,
	[Salesperson Key] [int] NOT NULL,
	[Picker Key] [int] NULL,
	[WWI Order ID] [int] NOT NULL,
	[WWI Backorder ID] [int] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Package] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Unit Price] [decimal](18, 2) NOT NULL,
	[Tax Rate] [decimal](18, 3) NOT NULL,
	[Total Excluding Tax] [decimal](18, 2) NOT NULL,
	[Tax Amount] [decimal](18, 2) NOT NULL,
	[Total Including Tax] [decimal](18, 2) NOT NULL,
	[Lineage Key] [int] NOT NULL)
WITH (DATA_COMPRESSION=PAGE);

--	Generate 231,412 * 100 rows of data in an OLTP table.  This takes a few minutes to execute, so we've already done it.
INSERT INTO dbo.fact_order_BIG_PAGE_COMPRESS
SELECT
	 [Order Key] + (250000 * ([Day Number] + ([Calendar Month Number] * 31))) AS [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM Fact.[Order]
CROSS JOIN
Dimension.Date
WHERE Date.Date <= '2013-04-10';

-- Add the typical NCI on the date column
CREATE NONCLUSTERED INDEX IX_fact_order_BIG_PAGE_COMPRESS ON dbo.fact_order_BIG_PAGE_COMPRESS ([order date key]);

/********************************************************************************************************************
 ************************Create OLAP Table with a Columnstore Index**************************************************
 *******************************************************************************************************************/

CREATE TABLE dbo.fact_order_BIG_CCI (
	[Order Key] [bigint] NOT NULL,
	[City Key] [int] NOT NULL,
	[Customer Key] [int] NOT NULL,
	[Stock Item Key] [int] NOT NULL,
	[Order Date Key] [date] NOT NULL,
	[Picked Date Key] [date] NULL,
	[Salesperson Key] [int] NOT NULL,
	[Picker Key] [int] NULL,
	[WWI Order ID] [int] NOT NULL,
	[WWI Backorder ID] [int] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Package] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Unit Price] [decimal](18, 2) NOT NULL,
	[Tax Rate] [decimal](18, 3) NOT NULL,
	[Total Excluding Tax] [decimal](18, 2) NOT NULL,
	[Tax Amount] [decimal](18, 2) NOT NULL,
	[Total Including Tax] [decimal](18, 2) NOT NULL,
	[Lineage Key] [int] NOT NULL);

-- Generate 231,412 * 100 rows of data in an OLTP table.  This is a little faster than with the OLTP table.
INSERT INTO dbo.fact_order_BIG_CCI
SELECT
	 [Order Key] + (250000 * ([Day Number] + ([Calendar Month Number] * 31))) AS [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM Fact.[Order]
CROSS JOIN
Dimension.Date
WHERE Date.Date <= '2013-04-10';

-- Create a columnstore index on the table.
CREATE CLUSTERED COLUMNSTORE INDEX CCI_fact_order_BIG_CCI ON dbo.fact_order_BIG_CCI;
GO
--	How much data do we have?  23,141,200 Rows.
SELECT
	COUNT(*),
	MIN([order date key]),
	MAX([order date key])
FROM dbo.fact_order_BIG_CCI;

-- Compare table sizes
CREATE TABLE #storage_data
(	table_name VARCHAR(MAX),
	rows_used BIGINT,
	reserved VARCHAR(50),
	data VARCHAR(50),
	index_size VARCHAR(50),
	unused VARCHAR(50));

INSERT INTO #storage_data
	(table_name, rows_used, reserved, data, index_size, unused)
EXEC sp_MSforeachtable "EXEC sp_spaceused '?'";

UPDATE #storage_data
	SET reserved = LEFT(reserved, LEN(reserved) - 3),
		data = LEFT(data, LEN(data) - 3),
		index_size = LEFT(index_size, LEN(index_size) - 3),
		unused = LEFT(unused, LEN(unused) - 3);
SELECT
	table_name,
	rows_used,
	reserved / 1024 AS data_space_reserved_mb,
	data / 1024 AS data_space_used_mb,
	index_size / 1024 AS index_size_mb,
	unused AS free_space_kb,
	CAST(CAST(data AS DECIMAL(24,2)) / CAST(rows_used AS DECIMAL(24,2)) AS DECIMAL(24,4)) AS kb_per_row
FROM #storage_data
WHERE rows_used > 0
AND table_name IN ('fact_order_BIG', 'fact_order_BIG_CCI', 'fact_order_BIG_PAGE_COMPRESS')
ORDER BY CAST(reserved AS INT) DESC;

DROP TABLE #storage_data;
GO

/********************************************************************************************************************
 ***********************************Batch Execution******************************************************************
 *******************************************************************************************************************/

 -- Turn on actual execution plan
 SELECT
	COUNT(*),
	MIN([order date key]),
	MAX([order date key])
FROM dbo.fact_order_BIG_CCI
WHERE [order date key] >= '1/1/2016';

/********************************************************************************************************************
 **********************************Rowgroup and Segment Metadata*****************************************************
 *******************************************************************************************************************/

 -- Row Groups
SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	partitions.partition_number,
	column_store_row_groups.row_group_id,
	column_store_row_groups.state_description,
	column_store_row_groups.total_rows,
	column_store_row_groups.size_in_bytes
FROM sys.column_store_row_groups
INNER JOIN sys.indexes
ON indexes.index_id = column_store_row_groups.index_id
AND indexes.object_id = column_store_row_groups.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.partitions
ON partitions.partition_number = column_store_row_groups.partition_number
AND partitions.index_id = indexes.index_id
AND partitions.object_id = tables.object_id
WHERE tables.name = 'fact_order_BIG_CCI'
ORDER BY tables.object_id, indexes.index_id, column_store_row_groups.row_group_id;

-- Segments - This is the key metadata used to simplify execution plans and greatly speed up queries!
SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	columns.name AS column_name,
	partitions.partition_number,
	column_store_segments.*
FROM sys.column_store_segments
INNER JOIN sys.partitions
ON column_store_segments.hobt_id = partitions.hobt_id
INNER JOIN sys.indexes
ON indexes.index_id = partitions.index_id
AND indexes.object_id = partitions.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.columns
ON tables.object_id = columns.object_id
AND column_store_segments.column_id = columns.column_id
WHERE tables.name = 'fact_order_BIG_CCI'
ORDER BY columns.name, column_store_segments.segment_id;

/********************************************************************************************************************
 *****************************Columnstore Index Delete Operations****************************************************
 *******************************************************************************************************************/

 SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	partitions.partition_number,
	column_store_row_groups.row_group_id,
	column_store_row_groups.state_description,
	column_store_row_groups.total_rows,
	column_store_row_groups.size_in_bytes,
	column_store_row_groups.deleted_rows,
	internal_partitions.partition_id,
	internal_partitions.internal_object_type_desc,
	internal_partitions.rows
FROM sys.column_store_row_groups
INNER JOIN sys.indexes
ON indexes.index_id = column_store_row_groups.index_id
AND indexes.object_id = column_store_row_groups.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.partitions
ON partitions.partition_number = column_store_row_groups.partition_number
AND partitions.index_id = indexes.index_id
AND partitions.object_id = tables.object_id
LEFT JOIN sys.internal_partitions
ON internal_partitions.object_id = tables.object_id
AND column_store_row_groups.deleted_rows > 0
WHERE tables.name = 'fact_order_BIG_CCI'
ORDER BY indexes.index_id, column_store_row_groups.row_group_id;
 
DELETE
FROM dbo.fact_order_BIG_CCI
WHERE fact_order_BIG_CCI.[Order Key] >= 8000001
AND fact_order_BIG_CCI.[Order Key] < 8000101;

SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	partitions.partition_number,
	column_store_row_groups.row_group_id,
	column_store_row_groups.state_description,
	column_store_row_groups.total_rows,
	column_store_row_groups.size_in_bytes,
	column_store_row_groups.deleted_rows,
	internal_partitions.partition_id,
	internal_partitions.internal_object_type_desc,
	internal_partitions.rows
FROM sys.column_store_row_groups
INNER JOIN sys.indexes
ON indexes.index_id = column_store_row_groups.index_id
AND indexes.object_id = column_store_row_groups.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.partitions
ON partitions.partition_number = column_store_row_groups.partition_number
AND partitions.index_id = indexes.index_id
AND partitions.object_id = tables.object_id
LEFT JOIN sys.internal_partitions
ON internal_partitions.object_id = tables.object_id
AND column_store_row_groups.deleted_rows > 0
WHERE tables.name = 'fact_order_BIG_CCI'
ORDER BY indexes.index_id, column_store_row_groups.row_group_id;

/********************************************************************************************************************
 *****************************Columnstore Index Update Operations****************************************************
 *******************************************************************************************************************/

SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	partitions.partition_number,
	column_store_row_groups.*
FROM sys.column_store_row_groups
INNER JOIN sys.indexes
ON indexes.index_id = column_store_row_groups.index_id
AND indexes.object_id = column_store_row_groups.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.partitions
ON partitions.partition_number = column_store_row_groups.partition_number
AND partitions.index_id = indexes.index_id
AND partitions.object_id = tables.object_id
WHERE tables.name = 'fact_order_BIG_CCI'
ORDER BY indexes.index_id, column_store_row_groups.row_group_id;

UPDATE fact_order_BIG_CCI
	SET Quantity = 1
FROM dbo.fact_order_BIG_CCI
WHERE fact_order_BIG_CCI.[Order Key] >= 8000101
AND fact_order_BIG_CCI.[Order Key] < 8000106;

SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	partitions.partition_number,
	column_store_row_groups.row_group_id,
	column_store_row_groups.state_description,
	column_store_row_groups.total_rows,
	column_store_row_groups.size_in_bytes,
	column_store_row_groups.deleted_rows,
	internal_partitions.partition_id,
	internal_partitions.internal_object_type_desc,
	internal_partitions.rows
FROM sys.column_store_row_groups
INNER JOIN sys.indexes
ON indexes.index_id = column_store_row_groups.index_id
AND indexes.object_id = column_store_row_groups.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.partitions
ON partitions.partition_number = column_store_row_groups.partition_number
AND partitions.index_id = indexes.index_id
AND partitions.object_id = tables.object_id
LEFT JOIN sys.internal_partitions
ON internal_partitions.object_id = tables.object_id
AND column_store_row_groups.deleted_rows > 0
WHERE tables.name = 'fact_order_BIG_CCI'
ORDER BY indexes.index_id, column_store_row_groups.row_group_id;

/********************************************************************************************************************
 ***********************************Columnstore Data Order***********************************************************
 *******************************************************************************************************************/

SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	columns.name AS column_name,
	partitions.partition_number,
	column_store_segments.segment_id,
	column_store_segments.min_data_id,
	column_store_segments.max_data_id,
	column_store_segments.row_count
FROM sys.column_store_segments
INNER JOIN sys.partitions
ON column_store_segments.hobt_id = partitions.hobt_id
INNER JOIN sys.indexes
ON indexes.index_id = partitions.index_id
AND indexes.object_id = partitions.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.columns
ON tables.object_id = columns.object_id
AND column_store_segments.column_id = columns.column_id
WHERE tables.name = 'fact_order_BIG_CCI'
AND columns.name = 'Order Date Key'
ORDER BY tables.name, columns.name, column_store_segments.segment_id;

SELECT
	SUM([Quantity])
FROM dbo.fact_order_BIG_CCI
WHERE [Order Date Key] >= '1/1/2016'
AND [Order Date Key] < '2/1/2016';

CREATE TABLE dbo.fact_order_BIG_CCI_ORDERED (
	[Order Key] [bigint] NOT NULL,
	[City Key] [int] NOT NULL,
	[Customer Key] [int] NOT NULL,
	[Stock Item Key] [int] NOT NULL,
	[Order Date Key] [date] NOT NULL,
	[Picked Date Key] [date] NULL,
	[Salesperson Key] [int] NOT NULL,
	[Picker Key] [int] NULL,
	[WWI Order ID] [int] NOT NULL,
	[WWI Backorder ID] [int] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Package] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Unit Price] [decimal](18, 2) NOT NULL,
	[Tax Rate] [decimal](18, 3) NOT NULL,
	[Total Excluding Tax] [decimal](18, 2) NOT NULL,
	[Tax Amount] [decimal](18, 2) NOT NULL,
	[Total Including Tax] [decimal](18, 2) NOT NULL,
	[Lineage Key] [int] NOT NULL);

CREATE CLUSTERED INDEX CCI_fact_order_BIG_CCI_ORDERED ON dbo.fact_order_BIG_CCI_ORDERED ([Order Date Key]);

INSERT INTO dbo.fact_order_BIG_CCI_ORDERED
SELECT
	 [Order Key] + (250000 * ([Day Number] + ([Calendar Month Number] * 31))) AS [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM Fact.[Order]
CROSS JOIN
Dimension.Date
WHERE Date.Date <= '2013-04-10';

-- Use MAPDOP = 1 to ensure that parallelism does not affect data order when the index is built.  We want it in a single ordered thread.
-- Since we do not build columnstore indexes from scratch often, the potential added time is 100% worth the wait.
CREATE CLUSTERED COLUMNSTORE INDEX CCI_fact_order_BIG_CCI_ORDERED ON dbo.fact_order_BIG_CCI_ORDERED WITH (MAXDOP = 1, DROP_EXISTING = ON);
GO

SELECT
	SUM([Quantity])
FROM dbo.fact_order_BIG_CCI_ORDERED
WHERE [Order Date Key] >= '1/1/2016'
AND [Order Date Key] < '2/1/2016';

SELECT
	tables.name AS table_name,
	indexes.name AS index_name,
	columns.name AS column_name,
	partitions.partition_number,
	column_store_segments.segment_id,
	column_store_segments.min_data_id,
	column_store_segments.max_data_id,
	column_store_segments.row_count
FROM sys.column_store_segments
INNER JOIN sys.partitions
ON column_store_segments.hobt_id = partitions.hobt_id
INNER JOIN sys.indexes
ON indexes.index_id = partitions.index_id
AND indexes.object_id = partitions.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id
INNER JOIN sys.columns
ON tables.object_id = columns.object_id
AND column_store_segments.column_id = columns.column_id
WHERE tables.name = 'fact_order_BIG_CCI_ORDERED'
AND columns.name = 'Order Date Key'
ORDER BY tables.name, columns.name, column_store_segments.segment_id;

/********************************************************************************************************************
 ********************************Partitioning************************************************************************
 *******************************************************************************************************************/
USE WideWorldImportersDW;
GO

ALTER DATABASE WideWorldImportersDW ADD FILEGROUP WideWorldImportersDW_2013_fg;
ALTER DATABASE WideWorldImportersDW ADD FILEGROUP WideWorldImportersDW_2014_fg;
ALTER DATABASE WideWorldImportersDW ADD FILEGROUP WideWorldImportersDW_2015_fg;
ALTER DATABASE WideWorldImportersDW ADD FILEGROUP WideWorldImportersDW_2016_fg;
ALTER DATABASE WideWorldImportersDW ADD FILEGROUP WideWorldImportersDW_2017_fg;

ALTER DATABASE WideWorldImportersDW ADD FILE
	(NAME = WideWorldImportersDW_2013_data, FILENAME = 'C:\SQLData\WideWorldImportersDW_2013_data.ndf',
	 SIZE = 200MB, MAXSIZE = UNLIMITED, FILEGROWTH = 1GB)
TO FILEGROUP WideWorldImportersDW_2013_fg;
ALTER DATABASE WideWorldImportersDW ADD FILE
	(NAME = WideWorldImportersDW_2014_data, FILENAME = 'C:\SQLData\WideWorldImportersDW_2014_data.ndf',
	 SIZE = 200MB, MAXSIZE = UNLIMITED, FILEGROWTH = 1GB)
TO FILEGROUP WideWorldImportersDW_2014_fg;
ALTER DATABASE WideWorldImportersDW ADD FILE
	(NAME = WideWorldImportersDW_2015_data, FILENAME = 'C:\SQLData\WideWorldImportersDW_2015_data.ndf',
	 SIZE = 200MB, MAXSIZE = UNLIMITED, FILEGROWTH = 1GB)
TO FILEGROUP WideWorldImportersDW_2015_fg;
ALTER DATABASE WideWorldImportersDW ADD FILE
	(NAME = WideWorldImportersDW_2016_data, FILENAME = 'C:\SQLData\WideWorldImportersDW_2016_data.ndf',
	 SIZE = 200MB, MAXSIZE = UNLIMITED, FILEGROWTH = 1GB)
TO FILEGROUP WideWorldImportersDW_2016_fg;
ALTER DATABASE WideWorldImportersDW ADD FILE
	(NAME = WideWorldImportersDW_2017_data, FILENAME = 'C:\SQLData\WideWorldImportersDW_2017_data.ndf',
	 SIZE = 200MB, MAXSIZE = UNLIMITED, FILEGROWTH = 1GB)
TO FILEGROUP WideWorldImportersDW_2017_fg;

CREATE PARTITION FUNCTION fact_order_BIG_CCI_years_function (DATE)
AS RANGE RIGHT FOR VALUES
	('1/1/2014', '1/1/2015', '1/1/2016', '1/1/2017');
GO

CREATE PARTITION SCHEME fact_order_BIG_CCI_years_scheme
AS PARTITION fact_order_BIG_CCI_years_function
TO (WideWorldImportersDW_2013_fg, WideWorldImportersDW_2014_fg, WideWorldImportersDW_2015_fg, WideWorldImportersDW_2016_fg, WideWorldImportersDW_2017_fg);
GO

CREATE TABLE dbo.fact_order_BIG_CCI_ORDERED_PARTITIONED (
	[Order Key] [bigint] NOT NULL,
	[City Key] [int] NOT NULL,
	[Customer Key] [int] NOT NULL,
	[Stock Item Key] [int] NOT NULL,
	[Order Date Key] [date] NOT NULL,
	[Picked Date Key] [date] NULL,
	[Salesperson Key] [int] NOT NULL,
	[Picker Key] [int] NULL,
	[WWI Order ID] [int] NOT NULL,
	[WWI Backorder ID] [int] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Package] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Unit Price] [decimal](18, 2) NOT NULL,
	[Tax Rate] [decimal](18, 3) NOT NULL,
	[Total Excluding Tax] [decimal](18, 2) NOT NULL,
	[Tax Amount] [decimal](18, 2) NOT NULL,
	[Total Including Tax] [decimal](18, 2) NOT NULL,
	[Lineage Key] [int] NOT NULL)
	ON fact_order_BIG_CCI_years_scheme([Order Date Key]);

CREATE CLUSTERED INDEX CI_fact_order_BIG_CCI_ORDERED_PARTITIONED ON dbo.fact_order_BIG_CCI_ORDERED_PARTITIONED ([Order Date Key]);

INSERT INTO dbo.fact_order_BIG_CCI_ORDERED_PARTITIONED
SELECT
	 [Order Key] + (250000 * ([Day Number] + ([Calendar Month Number] * 31))) AS [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM Fact.[Order]
CROSS JOIN
Dimension.Date
WHERE Date.Date <= '2013-04-10'
ORDER BY [Order].[Order Date Key];

CREATE CLUSTERED COLUMNSTORE INDEX CI_fact_order_BIG_CCI_ORDERED_PARTITIONED ON dbo.fact_order_BIG_CCI_ORDERED_PARTITIONED WITH (MAXDOP = 1, DROP_EXISTING = ON);
GO

SELECT
	SUM([Quantity])
FROM dbo.fact_order_BIG_CCI_ORDERED_PARTITIONED
WHERE [Order Date Key] >= '1/1/2016'
AND [Order Date Key] < '2/1/2016';

/********************************************************************************************************************
 ********************************Archive Compression*****************************************************************
 *******************************************************************************************************************/

CREATE TABLE dbo.fact_order_BIG_CCI_ORDERED_ARCHIVE (
	[Order Key] [bigint] NOT NULL,
	[City Key] [int] NOT NULL,
	[Customer Key] [int] NOT NULL,
	[Stock Item Key] [int] NOT NULL,
	[Order Date Key] [date] NOT NULL,
	[Picked Date Key] [date] NULL,
	[Salesperson Key] [int] NOT NULL,
	[Picker Key] [int] NULL,
	[WWI Order ID] [int] NOT NULL,
	[WWI Backorder ID] [int] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Package] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Unit Price] [decimal](18, 2) NOT NULL,
	[Tax Rate] [decimal](18, 3) NOT NULL,
	[Total Excluding Tax] [decimal](18, 2) NOT NULL,
	[Tax Amount] [decimal](18, 2) NOT NULL,
	[Total Including Tax] [decimal](18, 2) NOT NULL,
	[Lineage Key] [int] NOT NULL);

CREATE CLUSTERED INDEX CCI_fact_order_BIG_CCI_ORDERED_ARCHIVE ON dbo.fact_order_BIG_CCI_ORDERED_ARCHIVE ([Order Date Key]);

INSERT INTO dbo.fact_order_BIG_CCI_ORDERED_ARCHIVE
SELECT
	 [Order Key] + (250000 * ([Day Number] + ([Calendar Month Number] * 31))) AS [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM Fact.[Order]
CROSS JOIN
Dimension.Date
WHERE Date.Date <= '2013-04-10';

CREATE CLUSTERED COLUMNSTORE INDEX CCI_fact_order_BIG_CCI_ORDERED_ARCHIVE ON dbo.fact_order_BIG_CCI_ORDERED_ARCHIVE WITH (MAXDOP = 1, DROP_EXISTING = ON, DATA_COMPRESSION = COLUMNSTORE_ARCHIVE);
GO
 
-- Compare table sizes
CREATE TABLE #storage_data
(	table_name VARCHAR(MAX),
	rows_used BIGINT,
	reserved VARCHAR(50),
	data VARCHAR(50),
	index_size VARCHAR(50),
	unused VARCHAR(50));

INSERT INTO #storage_data
	(table_name, rows_used, reserved, data, index_size, unused)
EXEC sp_MSforeachtable "EXEC sp_spaceused '?'";

UPDATE #storage_data
	SET reserved = LEFT(reserved, LEN(reserved) - 3),
		data = LEFT(data, LEN(data) - 3),
		index_size = LEFT(index_size, LEN(index_size) - 3),
		unused = LEFT(unused, LEN(unused) - 3);
SELECT
	table_name,
	rows_used,
	reserved / 1024 AS data_space_reserved_mb,
	data / 1024 AS data_space_used_mb,
	index_size / 1024 AS index_size_mb,
	unused AS free_space_kb,
	CAST(CAST(data AS DECIMAL(24,2)) / CAST(rows_used AS DECIMAL(24,2)) AS DECIMAL(24,4)) AS kb_per_row
FROM #storage_data
WHERE rows_used > 0
AND table_name LIKE 'fact_order_BIG%'
ORDER BY CAST(reserved AS INT) DESC;

DROP TABLE #storage_data;
GO

/********************************************************************************************************************
 ********************************Nonclutered Columnstore Indexes*****************************************************
 *******************************************************************************************************************/

CREATE NONCLUSTERED COLUMNSTORE INDEX NCI_fact_order_BIG_Quantity ON dbo.fact_order_BIG ([Order Date Key], Quantity);
GO

SELECT
	SUM([Quantity])
FROM dbo.fact_order_BIG
WHERE [Order Date Key] >= '1/1/2016'
AND [Order Date Key] < '2/1/2016';
-- Where oh where is my rowgroup elimination!? :-\

CREATE TABLE dbo.fact_order_BIG_COVERING (
	[Order Key] [bigint] NOT NULL CONSTRAINT PK_fact_order_BIG_COVERING PRIMARY KEY CLUSTERED,
	[City Key] [int] NOT NULL,
	[Customer Key] [int] NOT NULL,
	[Stock Item Key] [int] NOT NULL,
	[Order Date Key] [date] NOT NULL,
	[Picked Date Key] [date] NULL,
	[Salesperson Key] [int] NOT NULL,
	[Picker Key] [int] NULL,
	[WWI Order ID] [int] NOT NULL,
	[WWI Backorder ID] [int] NULL,
	[Description] [nvarchar](100) NOT NULL,
	[Package] [nvarchar](50) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Unit Price] [decimal](18, 2) NOT NULL,
	[Tax Rate] [decimal](18, 3) NOT NULL,
	[Total Excluding Tax] [decimal](18, 2) NOT NULL,
	[Tax Amount] [decimal](18, 2) NOT NULL,
	[Total Including Tax] [decimal](18, 2) NOT NULL,
	[Lineage Key] [int] NOT NULL);

--	Generate 231,412 * 100 rows of data in an OLTP table.  This takes a few minutes to execute, so we've already done it.
INSERT INTO dbo.fact_order_BIG_COVERING
SELECT
	 [Order Key] + (250000 * ([Day Number] + ([Calendar Month Number] * 31))) AS [Order Key]
    ,[City Key]
    ,[Customer Key]
    ,[Stock Item Key]
    ,[Order Date Key]
    ,[Picked Date Key]
    ,[Salesperson Key]
    ,[Picker Key]
    ,[WWI Order ID]
    ,[WWI Backorder ID]
    ,[Description]
    ,[Package]
    ,[Quantity]
    ,[Unit Price]
    ,[Tax Rate]
    ,[Total Excluding Tax]
    ,[Tax Amount]
    ,[Total Including Tax]
    ,[Lineage Key]
FROM Fact.[Order]
CROSS JOIN
Dimension.Date
WHERE Date.Date <= '2013-04-10';

-- Add a covering index for the quantity query we are testing with.
CREATE NONCLUSTERED INDEX NCI_fact_order_BIG_Quantity ON dbo.fact_order_BIG_COVERING ([Order Date Key]) INCLUDE (Quantity);
GO

-- Execution plan on!
SELECT
	SUM([Quantity])
FROM dbo.fact_order_BIG_COVERING
WHERE [Order Date Key] >= '1/1/2016'
AND [Order Date Key] < '2/1/2016';
GO

/* Cleanup
DROP INDEX NCI_fact_order_BIG_Quantity ON dbo.fact_order_BIG;
DROP TABLE dbo.fact_order_BIG;
DROP TABLE dbo.fact_order_BIG_CCI;
DROP TABLE dbo.fact_order_BIG_CCI_ORDERED;
DROP TABLE dbo.fact_order_BIG_CCI_ORDERED_PARTITIONED;
DROP TABLE dbo.fact_order_BIG_CCI_ORDERED_ARCHIVE;
DROP TABLE dbo.fact_order_BIG_COVERING;
GO
*/